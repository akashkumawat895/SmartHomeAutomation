<?php
require 'PHPMailerAutoload.php'; // for php mailer
//Create a new PHPMailer instance


mysql_connect('localhost','cpadmin1_dzoic','mondon3572002');
mysql_select_db('cpadmin1_dzoic');


function getAge($birth){
$t = time();
$age = ($birth < 0) ? ( $t + ($birth * -1) ) : $t - $birth;
return floor($age/31536000);
}

//$sql = "SELECT * FROM `members` WHERE `verified` = '1' ORDER BY `mem_id` DESC LIMIT 1,10 ";
$sql = "SELECT * FROM `members` WHERE `verified` = '1' AND `email` = 'vikektherock1@gmail.com' OR `email` = 'vinodkumawat2020@gmail.com' OR `email` = 'test12345@chemicalpulse.com' OR `email` = 'sanjeev.naroliya@gmail.com' OR `email` = 'g.chemicalpulse@gmail.com' OR `email` = 'luvox2@gmail.com' ";
//$sql = "SELECT * FROM `members` WHERE `verified` = '1' AND `email` = 'vinodkumawat2020@gmail.com' ";

$query = mysql_query($sql);
//echo $number_row = mysql_num_rows($query);
while($result = mysql_fetch_assoc($query)){
	
	//echo '<br><br>' . $sql . '<br><br>';
	
	// 
	/*echo '<pre>';
	print_r($result);
	echo '</pre>';*/
	
	
	//$search_sql = "SELECT `src_id`, `mem_id`, `name` FROM `searches` WHERE `mem_id` = '" . $result['mem_id'] . "'";
	$search_sql = "SELECT * FROM `searches` WHERE `mem_id` = '" . $result['mem_id'] . "' ORDER BY `src_id` DESC LIMIT 1";
	$search_query = mysql_query($search_sql);
	$number_row = mysql_num_rows($search_query);
	
	if($number_row > 0){
	
	
	
	//echo '<br><br>' . $search_sql . '<br><br>';	
	
		$search_result = mysql_fetch_assoc($search_query);
		
		
		/*echo '<pre>';
		print_r($search_result);
		echo '</pre><br><br>';*/
		
		
		
		
		$criteria = explode('&', $search_result['criteria']);
		
		//echo '<pre>';
		//print_r($criteria);
		//echo '</pre>';
		
		foreach($criteria as $key => $val){
		
			//echo $key . '<br />';
			
			//echo $val . '<br />';
			
			list($lable, $value) = explode("=", $val);
			
			$$lable =  rawurldecode($value);

			
		
		}
		
		
		//echo 'fname - ' . $fname . '<br />';
		
		//echo 'field_effe5a7672 - ' . $field_effe5a7672 . '<br />';
		
		$fname = preg_replace('/\+/', ' ',$fname);
		$lname = preg_replace('/\+/', ' ',$lname);
		$keyword = preg_replace('/\+/', ' ',$keyword);
		
		
		if(isset($ethnicity) && $ethnicity != ""){
			$ethnicity = explode('|',$ethnicity);
			array_shift($ethnicity);
			array_pop($ethnicity);
		}
		
		if(isset($ethnicity) && $ethnicity != ""){
			$field_effe5a7672 = explode('|',$field_effe5a7672);
			array_shift($field_effe5a7672);
			array_pop($field_effe5a7672);
		}
		
		if(isset($ethnicity) && $ethnicity != ""){
			$field_b586ce204d = explode('|',$field_b586ce204d);
			array_shift($field_b586ce204d);
			array_pop($field_b586ce204d);
		}
		
		if(isset($ethnicity) && $ethnicity != ""){
			$personality_type = explode('|',$personality_type);
			array_shift($personality_type);
			array_pop($personality_type);
		}
		
		if(isset($ethnicity) && $ethnicity != ""){
			$artistic_talent_interest = explode('|',$artistic_talent_interest);
			array_shift($artistic_talent_interest);
			array_pop($artistic_talent_interest);
		}
		
		if(isset($ethnicity) && $ethnicity != ""){
			$smoking_drinking_drugs_ = explode('|',$smoking_drinking_drugs_);
			array_shift($smoking_drinking_drugs_);
			array_pop($smoking_drinking_drugs_);
		}
		
		if(isset($ethnicity) && $ethnicity != ""){
			$field_abd46adad2 = explode('|',$field_abd46adad2);
			array_shift($field_abd46adad2);
			array_pop($field_abd46adad2);
		}
			
		
	
		//echo 'keyword - ' . $keyword . '<br />';
		//print_r($field_abd46adad2);
		
		
		
// =============================== search query ============================== //		
	
		$search_sql_next = "SELECT members.mem_id FROM members,profiles,members_settings,network AS n WHERE members.verified='1' 
		
		AND members.mem_id=profiles.mem_id 
		
		AND members.mem_id=members_settings.mem_id 
		
		AND members.mem_id=n.mem_id 
		
		AND members.mem_id!= '" . $search_result['mem_id'] . "' 
		
		AND members.mem_id > 100000  " . 
		
		($country != "" ? " AND country = '". $country ."'" : '' ) . 
		
		($state != "" ? " AND state = '". $state ."'" : '' ) . 
		
		($city != "" ? " AND city = '". $city ."'" : '' ) . 
		
		($fname != "" ? " AND members.fname LIKE '". $fname ."%'" : '' ) . 
		
		($lname != "" ? " AND members.lname LIKE '". $lname ."%'" : '' ) . 
		
		($email != "" ? " AND members.email LIKE '". $email ."%'" : '' ) .
		
		($gender != "" ? " AND profiles.gender = '". $gender ."'" : '' ) . 
		
		($field_d5ea7b90e5 != "" ? " AND profiles.field_d5ea7b90e5 = '". $field_d5ea7b90e5 ."'" : '' ) . 
		
		((isset($ethnicity) && $ethnicity != "") ? " AND ( profiles.ethnicity LIKE '%|". $ethnicity['0'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['1'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['2'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['3'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['4'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['5'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['6'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['7'] ."|%' OR profiles.ethnicity LIKE '%|". $ethnicity['8'] ."|%')" : '' ) . 
		
		($field_e2e98183a7 != "" ? " AND profiles.field_e2e98183a7 = '". $field_e2e98183a7 ."'" : '' ) . 
		
		($relationship_status != "" ? " AND profiles.relationship_status = '". $relationship_status ."'" : '' ) . 
		
		((isset($personality_type) && $personality_type != "") ? " AND ( profiles.personality_type LIKE '%|". $personality_type['0'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['1'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['2'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['3'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['4'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['5'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['6'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['7'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['8'] ."|%' OR profiles.personality_type LIKE '%|". $personality_type['9'] ."|%')" : '' ) . 
		
		((isset($field_b586ce204d) && $field_b586ce204d != "") ? " AND ( profiles.field_b586ce204d LIKE '%|". $field_b586ce204d['0'] ."|%' OR profiles.field_b586ce204d LIKE '%|". $field_b586ce204d['1'] ."|%' OR profiles.field_b586ce204d LIKE '%|". $field_b586ce204d['2'] ."|%' OR profiles.field_b586ce204d LIKE '%|". $field_b586ce204d['3'] ."|%' OR profiles.field_b586ce204d LIKE '%|". $field_b586ce204d['4'] ."|%')" : '' ) . 
		
		((isset($artistic_talent_interest) && $artistic_talent_interest != "") ? " AND ( profiles.artistic_talent_interest LIKE '%|". $artistic_talent_interest['0'] ."|%' OR profiles.artistic_talent_interest LIKE '%|". $artistic_talent_interest['1'] ."|%' OR profiles.artistic_talent_interest LIKE '%|". $artistic_talent_interest['2'] ."|%' OR profiles.artistic_talent_interest LIKE '%|". $artistic_talent_interest['3'] ."|%' OR profiles.artistic_talent_interest LIKE '%|". $artistic_talent_interest['4'] ."|%' OR profiles.artistic_talent_interest LIKE '%|". $artistic_talent_interest['5'] ."|%' OR profiles.artistic_talent_interest LIKE '%|". $artistic_talent_interest['6'] ."|%')" : '' ) .
		
		((isset($smoking_drinking_drugs_) && $smoking_drinking_drugs_ != "") ? " AND ( profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['0'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['1'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['2'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['3'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['4'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['5'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['6'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['7'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['8'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['9'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['10'] ."|%' OR profiles.smoking_drinking_drugs_ LIKE '%|". $smoking_drinking_drugs_['11'] ."|%')" : '' ) .
		
		($want_children != "" ? " AND profiles.want_children = '". $want_children ."'" : '' ) .  
		
		($sexual_orientation_ != "" ? " AND profiles.sexual_orientation_ = '". $sexual_orientation_ ."'" : '' ) .
		
		($have_children != "" ? " AND profiles.have_children = '". $have_children ."'" : '' ) .
		
		($field_aa76a46b11 != "" ? " AND profiles.field_aa76a46b11 = '". $field_aa76a46b11 ."'" : '' ) .
		
		((isset($field_effe5a7672) && $field_effe5a7672 != "") ? " AND ( profiles.field_effe5a7672 LIKE '%|". $field_effe5a7672['0'] ."|%' OR profiles.field_effe5a7672 LIKE '%|". $field_effe5a7672['1'] ."|%' OR profiles.field_effe5a7672 LIKE '%|". $field_effe5a7672['2'] ."|%' OR profiles.field_effe5a7672 LIKE '%|". $field_effe5a7672['3'] ."|%')" : '' ) .
		
		($field_ccac1c8192 != "" ? " AND profiles.field_ccac1c8192 = '". $field_ccac1c8192 ."'" : '' ) .
		
		($field_02129ced64 != "" ? " AND profiles.field_02129ced64 = '". $field_02129ced64 ."'" : '' ) .
		
		($relationship_intimacy != "" ? " AND profiles.relationship_intimacy = '". $relationship_intimacy ."'" : '' ) .
		
		($field_a0e5f739c9 != "" ? " AND profiles.field_a0e5f739c9 = '". $field_a0e5f739c9 ."'" : '' ) .
		
		((isset($field_abd46adad2) && $field_abd46adad2 != "") ? " AND ( profiles.field_abd46adad2 LIKE '%|". $field_effe5a7672['0'] ."|%' OR profiles.field_abd46adad2 LIKE '%|". $field_effe5a7672['1'] ."|%' OR profiles.field_abd46adad2 LIKE '%|". $field_effe5a7672['2'] ."|%' OR profiles.field_abd46adad2 LIKE '%|". $field_effe5a7672['3'] ."|%' OR profiles.field_abd46adad2 LIKE '%|". $field_effe5a7672['4'] ."|%' OR profiles.field_abd46adad2 LIKE '%|". $field_effe5a7672['5'] ."|%' OR profiles.field_abd46adad2 LIKE '%|". $field_effe5a7672['6'] ."|%')" : '' ) .
		
		($field_2c4146376f != "" ? " AND profiles.field_2c4146376f = '". $field_2c4146376f ."'" : '' ) .
		
		($hair_color != "" ? " AND profiles.hair_color = '". $hair_color ."'" : '' ) .
		
		($keyword != "" ? " AND ( profiles.mem_id LIKE '%". $keyword ."%' OR profiles.joined LIKE '%". $keyword ."%' OR profiles.updated LIKE '%". $keyword ."%' OR profiles.last_visit LIKE '%". $keyword ."%' OR profiles.last_click LIKE '%". $keyword ."%' OR profiles.country LIKE '%". $keyword ."%' OR profiles.mood LIKE '%". $keyword ."%' OR profiles.ustatus LIKE '%". $keyword ."%' OR profiles.state LIKE '%". $keyword ."%' OR profiles.city LIKE '%". $keyword ."%' OR profiles.postal_code LIKE '%". $keyword ."%' OR profiles.latitude LIKE '%". $keyword ."%' OR profiles.longitude LIKE '%". $keyword ."%' OR profiles.gender LIKE '%". $keyword ."%' OR profiles.birthdate LIKE '%". $keyword ."%' OR profiles.photo LIKE '%". $keyword ."%' OR profiles.photo_med LIKE '%". $keyword ."%' OR profiles.photo_small LIKE '%". $keyword ."%' OR profiles.template LIKE '%". $keyword ."%' OR profiles.headline LIKE '%". $keyword ."%' OR profiles.media LIKE '%". $keyword ."%' OR profiles.personal_overview LIKE '%". $keyword ."%' OR profiles.diagnosis LIKE '%". $keyword ."%' OR profiles.field_5c0f6573ac LIKE '%". $keyword ."%' OR profiles.field_73c2353b86 LIKE '%". $keyword ."%' OR profiles.field_d5ea7b90e5 LIKE '%". $keyword ."%' OR profiles.ethnicity LIKE '%". $keyword ."%' OR profiles.field_e2e98183a7 LIKE '%". $keyword ."%' OR profiles.relationship_status LIKE '%". $keyword ."%' OR profiles.field_effe5a7672 LIKE '%". $keyword ."%' OR profiles.field_02129ced64 LIKE '%". $keyword ."%' OR profiles.field_aa76a46b11 LIKE '%". $keyword ."%' OR profiles.field_ccac1c8192 LIKE '%". $keyword ."%' OR profiles.have_children LIKE '%". $keyword ."%' OR profiles.want_children LIKE '%". $keyword ."%' OR profiles.personality_type LIKE '%". $keyword ."%' OR profiles.i_would_like_to_meet LIKE '%". $keyword ."%' OR profiles.zodiac_sign LIKE '%". $keyword ."%' OR profiles.sexual_orientation_ LIKE '%". $keyword ."%' OR profiles.smoking_drinking_drugs_ LIKE '%". $keyword ."%' OR profiles.field_b586ce204d LIKE '%". $keyword ."%' OR profiles.artistic_talent_interest LIKE '%". $keyword ."%' OR profiles.top_movies_books_bands_composers_musical_artists LIKE '%". $keyword ."%' OR profiles.field_9e017e3219 LIKE '%". $keyword ."%' OR profiles.folder LIKE '%". $keyword ."%' OR profiles.approved LIKE '%". $keyword ."%' OR profiles.field_6f47d33406 LIKE '%". $keyword ."%' OR profiles.test LIKE '%". $keyword ."%' OR profiles.field_120aeec197 LIKE '%". $keyword ."%' OR profiles.open_to_an_age_gap_ LIKE '%". $keyword ."%' OR profiles.my_secrets_confessions_ LIKE '%". $keyword ."%' OR profiles.my_fetishes LIKE '%". $keyword ."%' OR profiles.sex_drive LIKE '%". $keyword ."%' OR profiles.as_a_lover_i_am_ LIKE '%". $keyword ."%' OR profiles.what_i_like_to_do_for_fun LIKE '%". $keyword ."%' OR profiles.body_type LIKE '%". $keyword ."%' OR profiles.field_3ee941bbfc LIKE '%". $keyword ."%' OR profiles.field_461db6fcec LIKE '%". $keyword ."%' OR profiles.seeking_relationship_type LIKE '%". $keyword ."%' OR profiles.as_a_lover_i_am LIKE '%". $keyword ."%' OR profiles.relationship_intimacy LIKE '%". $keyword ."%' OR profiles.field_a0e5f739c9 LIKE '%". $keyword ."%' OR profiles.field_2c4146376f LIKE '%". $keyword ."%' OR profiles.my_secrets_confessions LIKE '%". $keyword ."%' OR profiles.field_e30716dd98 LIKE '%". $keyword ."%' OR profiles.how_i_describe_the_person_i_ll_like_to_meet_ LIKE '%". $keyword ."%' OR profiles.field_6b8c4f4414 LIKE '%". $keyword ."%' OR profiles.field_abd46adad2 LIKE '%". $keyword ."%' OR profiles.hair_color LIKE '%". $keyword ."%' OR profiles.are_you_interested_in_bisexual_women_ LIKE '%". $keyword ."%' OR profiles.field_56ccade6b8 LIKE '%". $keyword ."%' OR profiles.are_you_interested_in_bisexual_men_ LIKE '%". $keyword ."%' OR profiles.field_e0dde61b23 LIKE '%". $keyword ."%' OR profiles.field_c4a5a38851 LIKE '%". $keyword ."%' OR profiles.are_you_interested_in_straight_women_ LIKE '%". $keyword ."%' OR profiles.field_44a11d3405 LIKE '%". $keyword ."%' OR profiles.are_you_interested_in_straight_men_ LIKE '%". $keyword ."%' OR profiles.field_6f4dc01917 LIKE '%". $keyword ."%' OR profiles.field_f611d3d9d3 LIKE '%". $keyword ."%' OR profiles.field_d89cad9ea9 LIKE '%". $keyword ."%' OR profiles.field_c42308b6db LIKE '%". $keyword ."%' OR profiles.field_661e0af452 LIKE '%". $keyword ."%' OR profiles.field_126454f3c8 LIKE '%". $keyword ."%' OR profiles.are_u_in_bisexual_women_st LIKE '%". $keyword ."%' OR profiles.are_u_in_bisexual_men_st LIKE '%". $keyword ."%' OR profiles.are_u_in_straight_women_bi LIKE '%". $keyword ."%' OR profiles.are_u_in_straight_men_bi LIKE '%". $keyword ."%' OR profiles.are_u_in_bisexual_men_gay LIKE '%". $keyword ."%' OR profiles.are_u_in_bisexual_men_ls LIKE '%". $keyword ."%')" : '' ) .
		
		" AND members_settings.hide_status != '1' 
		
		AND profiles.photo!='awaiting.gif' 
		
		AND profiles.photo!='' 
		
		LIMIT 0,4" ;
 
		
		$search_query_next = mysql_query($search_sql_next);
		$number_rows = mysql_num_rows($search_query_next);
		
			if($number_rows == 0){
			
				$sql_query2 = "SELECT * FROM profiles WHERE mem_id = '" . $result["mem_id"] ."'" ;
				$sql_result2 = mysql_query($sql_query2);
				$logged = mysql_fetch_assoc($sql_result2);
				
				
					// If member is male and none sexual orientation - Show straight and bisexual females //
				if ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 0){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 2 AND ( sexual_orientation_ = 1 OR sexual_orientation_ = 4 )
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				}
				// If member is female and none sexual orientation - Show straight and bisexual males	//
				elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 0){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 1 AND ( sexual_orientation_ = 1 OR sexual_orientation_ = 4 )
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				}
			
				// If member is male and straight - Show straight females //
				elseif ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 1){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 2 AND sexual_orientation_ = 1
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				// If member is female and straight - Show straight males //
				}elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 1){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 1 AND sexual_orientation_ = 1
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				// If member is male and Gay: Show only Gay or bisexual males //
				}elseif ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 2){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 1 AND ( sexual_orientation_ = 2 OR sexual_orientation_ = 4 )
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				}
				//  If member is male and bisexual: Show only Gay or bisexual males //
				elseif ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 4){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 1 AND ( sexual_orientation_ = 2 OR sexual_orientation_ = 4 )
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
				
				}
			
				// If female is Lesbian : Show Lesbian and Bisexual females //
				elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 3){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 2 AND ( sexual_orientation_ = 3 OR sexual_orientation_ = 4 )
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				// If female is bisexual: Show Lesbian and Bisexual females //
				}elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 4){
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000 AND gender = 2 AND ( sexual_orientation_ = 3 OR sexual_orientation_ = 4 )
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				}
				// Anything else, show all
				else{
			
					$search_sql_next = "SELECT mem_id FROM profiles AS members
					WHERE mem_id > 100000
					AND members.photo!='' AND members.photo!='awaiting.gif'
					ORDER BY rand()
					LIMIT 0,4";
			
				}
			$search_query_next = mysql_query($search_sql_next);
			
			} //if($number_rows == 0) 
		
		} //if($number_row > 0)  
		
		else{
		
			$sql_query2 = "SELECT * FROM profiles WHERE mem_id = '" . $result["mem_id"] ."'" ;
			$sql_result2 = mysql_query($sql_query2);
			$logged = mysql_fetch_assoc($sql_result2);
			
			
				// If member is male and none sexual orientation - Show straight and bisexual females //
			if ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 0){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 2 AND ( sexual_orientation_ = 1 OR sexual_orientation_ = 4 )
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			}
			// If member is female and none sexual orientation - Show straight and bisexual males	//
			elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 0){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 1 AND ( sexual_orientation_ = 1 OR sexual_orientation_ = 4 )
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			}
		
			// If member is male and straight - Show straight females //
			elseif ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 1){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 2 AND sexual_orientation_ = 1
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			// If member is female and straight - Show straight males //
			}elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 1){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 1 AND sexual_orientation_ = 1
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			// If member is male and Gay: Show only Gay or bisexual males //
			}elseif ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 2){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 1 AND ( sexual_orientation_ = 2 OR sexual_orientation_ = 4 )
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			}
			//  If member is male and bisexual: Show only Gay or bisexual males //
			elseif ($logged["gender"] == 1 && $logged["sexual_orientation_"] == 4){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 1 AND ( sexual_orientation_ = 2 OR sexual_orientation_ = 4 )
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
			
			}
		
			// If female is Lesbian : Show Lesbian and Bisexual females //
			elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 3){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 2 AND ( sexual_orientation_ = 3 OR sexual_orientation_ = 4 )
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			// If female is bisexual: Show Lesbian and Bisexual females //
			}elseif ($logged["gender"] == 2 && $logged["sexual_orientation_"] == 4){
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000 AND gender = 2 AND ( sexual_orientation_ = 3 OR sexual_orientation_ = 4 )
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			}
			// Anything else, show all
			else{
		
				$search_sql_next = "SELECT mem_id FROM profiles AS members
				WHERE mem_id > 100000
				AND members.photo!='' AND members.photo!='awaiting.gif'
				ORDER BY rand()
				LIMIT 0,4";
		
			}
			
			$search_query_next = mysql_query($search_sql_next);
			
			
		} // else
		
		// echo '<br><br>' . $search_sql_next . '<br><br>';
		
		
		
		
		$email_content = '<table width="100%"  border="0" cellspacing="0" cellpadding="0" background="http://chemicalpulse.com/photos/mail-bgimage.jpg"><tr><td><table width="100%"  border="0" cellspacing="0" cellpadding="0"><tr><td><a href="http://www.chemicalpulse.com" tar><img src="http://chemicalpulse.com/photos/mail-logo.jpg" /></a><br /><br /><font size="3" face="Arial, Helvetica, sans-serif, verdana" color="#ffffff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dear <strong>' . $result['fname'] . ' ' . $result['lname'] . ' </strong>, your weekly match from Chemicalpulse.com</font></td></tr></table><table width="100%" border="0" cellspacing="0" cellpadding="0">';
		
		
		while($search_result_next = mysql_fetch_assoc($search_query_next)){
		
		
		/*echo '<pre>';
		print_r($search_result_next);
		echo '</pre>';*/
		
		
		
	
		$thumb_sql = "SELECT pro.*, mem.* ,coun.name AS country, state.name AS state, city.name AS city FROM members AS mem 
		LEFT JOIN profiles AS pro ON mem.mem_id = pro.mem_id 
		LEFT JOIN geo_countries AS coun ON coun.con_id = pro.country 
		LEFT JOIN geo_states AS state ON state.sta_id = pro.state 
		LEFT JOIN geo_cities AS city ON city.cty_id  = pro.city  
		WHERE `mem`.`mem_id` = '" . $search_result_next['mem_id'] . "'";
		$thumb_query = mysql_query($thumb_sql);
		$thumb_result = mysql_fetch_assoc($thumb_query);
		
		
		
		
		//echo '<br><br>' . $thumb_sql . '<br><br>';	
		/*echo '<pre>';
		print_r($thumb_result);
		echo '</pre>';*/
		
		$thumbnail = '<img src="http://www.chemicalpulse.com/photos/'.$thumb_result["photo_small"].'" height="100" width="90"  />';
		$profile_link = 'http://www.chemicalpulse.com/profiles/' . $thumb_result["mem_id"] . '.html';
		
		$email_content .= '<tr><td valign="top" ><hr><table border="0" cellspacing="0" cellpadding="0"><tr height="10"><td colspan="4"></td></tr><tr><td width="10%"></td><td>' . $thumbnail . '</td><td width="5%"><td valign="top"><font size="2" face="Arial, Helvetica, sans-serif, verdana" color="#ffffff"><strong>Gender: </strong>' . ($thumb_result['gender'] == '1' ? 'Male' : 'Female') . '</font><br /><br /><font size="2" face="Arial, Helvetica, sans-serif, verdana" color="#ffffff"><strong>Age: </strong>' . getAge($thumb_result['birthdate']) . '</font><br /><br /><font size="2" face="Arial, Helvetica, sans-serif, verdana" color="#ffffff"><strong>Location: </strong> ' . $thumb_result["country"] . ', ' . $thumb_result["state"] .', ' . $thumb_result["city"]. '</font><br /></td></tr><tr><td width="10%"></td><td colspan="3"><a href="'.$profile_link.'"><font color="#fa73ff" size="3" face="Arial, Helvetica, sans-serif, verdana">' . $thumb_result["fname"] . ' ' . $thumb_result["lname"] . '</font></a></td></tr><tr height="10"><td colspan="4"></td></tr></table></td></tr>';	
		
		//echo 'Age are: ' . getAge($thumb_result['birthdate']);	
		
		}//while
		
		$email_content .= '<table width="100%" border="0" cellspacing="0" cellpadding="6" bgcolor="#000000"><tr><td><a href="http://www.chemicalpulse.com/homepage.html" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">MyChemicalPulse</font></a></td><td><a href="http://www.chemicalpulse.com/index.php?page=photos&section=edit" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">My photos</font></a></td><td><a href="http://www.chemicalpulse.com/index.php?page=search&section=members" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">Search</font></a></td><td><a href="http://www.chemicalpulse.com/index.php?page=mailbox&section=inbox" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">Mailbox</font></a></td><td><a href="http://www.chemicalpulse.com/index.php?page=views" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">Who viewed me?</font></a></td><td><a href="http://www.chemicalpulse.com/index.php?page=whos_new" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">Who\'s New?</font></a></td><td><a href="http://www.chemicalpulse.com/index.php?page=history" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">Who did I view?</font></a></td><td><a href="http://www.chemicalpulse.com/index.php?page=invite" ><font color="#ff00ea" face="Arial, Helvetica, sans-serif, verdana">Invite</font></a></td></td></tr></table></td></tr></table>';
		
		//echo '<br><br>' . $email_content . '<br><br>';
		
		
	/*	// ===================== Send Mail =================== // 
		
		$less = "<";
		$greater = ">";
		
		$To  = $result['email'];
		$Subject = "My Weekly Match";	 
		
		// To send HTML mail, you can set the Content-type header. //
		
		$Headers  = "MIME-Version: 1.0\n";
		$Headers .= "Content-type: text/html; charset=iso-8859-1\n";
		$Headers .= "From:  $less matches@chemicalpulse.com $greater\n";
		$Headers .= "Reply-To: matches@chemicalpulse.com\r\n";
		$Headers .= "Return-Path: <matches@chemicalpulse.com>\n";
		$Headers .= "X-Priority: 1\n"; //1 UrgentMessage, 3 Normal
		
		if(@mail($To, $Subject, $email_content, $Headers)){
		
		$Resultt = "<strong><font color=\"green\">Your message details submited successfully.</font>";
		
		}
		else{
		
		$Resultt =  "<strong><font color=\"red\">Your message details did not submited successfully, please try again.</font>";
		
		}
				
		//echo $Resultt;*/	
		
		//echo '<br><br>' . $result['email'] . '<br><br>';
		//SMTP needs accurate times, and the PHP time zone MUST be set
		//This should be done in your php.ini, but this is how to do it if you don't have access to that
		date_default_timezone_set('Etc/UTC');
		
		
		$mail = new PHPMailer();
		
		//Tell PHPMailer to use SMTP
		$mail->isSMTP();
		//Enable SMTP debugging
		// 0 = off (for production use)
		// 1 = client messages
		// 2 = client and server messages
		$mail->SMTPDebug = 0;
		//Ask for HTML-friendly debug output
		$mail->Debugoutput = 'html';
		//Set the hostname of the mail server
		$mail->Host = "mail.chemicalpulse.com";
		//Set the SMTP port number - likely to be 25, 465 or 587
		$mail->Port = 25;
		//Whether to use SMTP authentication
		$mail->SMTPAuth = true;
		//Username to use for SMTP authentication
		$mail->Username = "matches@chemicalpulse.com";
		//Password to use for SMTP authentication
		$mail->Password = "tEOFf4?W7pu*KqKz+i";
		//Set who the message is to be sent from
		$mail->setFrom('matches@chemicalpulse.com', '');
		//Set an alternative reply-to address
		$mail->addReplyTo('matches@chemicalpulse.com', '');
		//Set who the message is to be sent to
		//$mail->addAddress('vinodkumawat2020@gmail.com', 'John Doe');
		$mail->addAddress($result['email'], '');
		//Set the subject line
		$mail->Subject = 'My Weekly Match';
		//Read an HTML message body from an external file, convert referenced images to embedded, 
		//convert HTML into a basic plain-text alternative body
		//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
		$mail->msgHTML($email_content);
		//Replace the plain text body with one created manually
		//$mail->AltBody = 'This is a plain-text message body';
		//Attach an image file
		//$mail->addAttachment('images/phpmailer_mini.png');
		
		//send the message, check for errors
		if (!$mail->send()) {
		echo "Mailer Error: " . $mail->ErrorInfo;
		}
		
		
} // while

echo "<br /><br /><center><h1 style='color:red'>Email sent to " . mysql_num_rows($query) . " user</h1></center>";

?>