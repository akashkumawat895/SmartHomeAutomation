<?php
require_once "connection.php";
$email = $_GET['email'];
$token_id = $_GET['token_id'];


$sql = "SELECT * FROM `user_registration` WHERE email = '$email' AND token_id = '$token_id'";

$query_result = $conn->query($sql);
$records = $query_result->fetch_assoc();



$button_on_off_arr = json_decode($records['button_on_off']);

$new_arr = array();
foreach($button_on_off_arr as $button_on_off){
    $new_arr[] = $button_on_off;
}
echo $res_arr = implode(',',$new_arr);


?>