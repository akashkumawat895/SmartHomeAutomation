<?php
require_once "connection.php";


$postdata = file_get_contents("php://input");
if (isset($postdata)) {
    $request = json_decode($postdata); 
    $callBack   = $request->callBack;

    if($callBack == "doRregister") {
    	$credentials   = $request->form_data;
        $fullname   = $credentials->fullname;
        $email   = $credentials->email;
        $mobile   = $credentials->mobile;
        $password   = $credentials->password;
        $token_id = rand(1000, 9999);


        $sql = "INSERT INTO `user_registration` SET 
                    `full_name` = '". $fullname ."',      
                    `email` = '". $email ."',  
                    `phone` = '". $mobile ."', 
                    `password` = '". $password ."',
                    `token_id` = '". $token_id ."'
                    ";

        $query_result = $conn->query($sql);
        if($query_result){
            $response['status'] = true;
            
            require 'SMTPMail/PHPMailerAutoload.php'; // for php mailer

            $mail = new PHPMailer();
            
            //Tell PHPMailer to use SMTP
            $mail->isSMTP();
            //Enable SMTP debugging
            $mail->SMTPDebug = 0;
            //Ask for HTML-friendly debug output
            $mail->Debugoutput = 'html';
            //Set the hostname of the mail server
            $mail->Host = "ssl://hostname.com";
            //Set the SMTP port number - likely to be 25, 465 or 587
            $mail->Port = 465;
            //Whether to use SMTP authentication
            $mail->SMTPAuth = true;
            //Username to use for SMTP authentication
            $mail->Username = "SMTP Username";
            //Password to use for SMTP authentication
            $mail->Password = "SMTP Password";
            //Set who the message is to be sent from
            $mail->setFrom('akashkumawat895@gmail.com', 'Home Automation');
            //Set an alternative reply-to address
            //$mail->addReplyTo('akashkumawat895@gmail.com', '');
            //Set who the message is to be sent to
            $mail->addAddress($email, '');
            $mail->addAddress('akashkumawat895@gmail.com', '');
            //$mail->addAddress($result['email'], '');
            //Set the subject line
            $mail->Subject = 'Home Automation Token Id';
            
            $email_body = "Hi, $fullname";
            $email_body .= "<br><br>";
            $email_body .= "Your Username: '$email'";
            $email_body .= "<br>";
            $email_body .= "Your Password: '$password'";
            $email_body .= "<br>";
            $email_body .= "Your Token ID : '$token_id'";
            $email_body .= "<br><br>";
            $email_body .= "Thanks";
            $mail->msgHTML($email_body);
            
            //send the message, check for errors
            if ($mail->send()) {
            	 $response['msg']    = "You information submitted successfully! You Will get a Email.";
            } else {
            	echo "\n Mailer Error: " . $mail->ErrorInfo . "\n ";
            }

        } else {
            $response['status'] = false;
            $response['msg']    = "Something went wrong. Please try agian later!!";
        }
        
        echo json_encode($response);
    }

/*==========login==========*/

    if($callBack == "doLogin") {
        session_start();
        $credentials   = $request->form_data;
        $email   = $credentials->email;
        $password   = $credentials->password;


        $sql = "SELECT * FROM `user_registration` WHERE email = '$email' AND password = '$password'";

        $query_result = $conn->query($sql);
        if(mysqli_num_rows($query_result) > 0){
            $records    = $query_result->fetch_assoc();

            //$_SESSION['token_id'] = $records['token_id'];
            $sql2 = "UPDATE session SET token_id = '". $records['token_id'] ."' WHERE id=1 ";
            $query_result2 = $conn->query($sql2);

            $response['msg']    = "You are successfully login!";
            $response['status']    = true;
            //$response['records']    = $query_result->fetch_assoc();

        } else {
            $response['msg']    = "Sorry, You are not authorize!";
            $response['status']    = false;
        }
        
        echo json_encode($response);
    }

    if($callBack == "addButton") {

        $credentials   = $request->form_data;
        $buttonNames   = $request->button_name;


    
        $buttonArr = array();
        $buttonArr['d0'] = $credentials->d0;
        $buttonArr['d1'] = $credentials->d1;
        $buttonArr['d2'] = $credentials->d2;
        $buttonArr['d3'] = $credentials->d3;
        $buttonArr['d4'] = $credentials->d4;
        $buttonArr['d5'] = $credentials->d5;
        $buttonArr['d6'] = $credentials->d6;
        $buttonArr['d7'] = $credentials->d7;
        $buttonArr['d8'] = $credentials->d8;
        $buttonArr['d9'] = $credentials->d9;
        $buttonArr['d10'] = $credentials->d10;

        $buttonNameArr = array();
        $buttonNameArr['d0_name'] = $buttonNames->d0_name;
        $buttonNameArr['d1_name'] = $buttonNames->d1_name;
        $buttonNameArr['d2_name'] = $buttonNames->d2_name;
        $buttonNameArr['d3_name'] = $buttonNames->d3_name;
        $buttonNameArr['d4_name'] = $buttonNames->d4_name;
        $buttonNameArr['d5_name'] = $buttonNames->d5_name;
        $buttonNameArr['d6_name'] = $buttonNames->d6_name;
        $buttonNameArr['d7_name'] = $buttonNames->d7_name;
        $buttonNameArr['d8_name'] = $buttonNames->d8_name;
        $buttonNameArr['d9_name'] = $buttonNames->d9_name;
        $buttonNameArr['d10_name'] = $buttonNames->d10_name;

        $btn_json = json_encode($buttonArr);
        $btn_name_json = json_encode($buttonNameArr);


        $sql12 = "SELECT * FROM `session` WHERE id=1";
        $query_result12 = $conn->query($sql12);
        $records12    = $query_result12->fetch_assoc();
        $tokenId = $records12['token_id'];
        

        
       $sql = "UPDATE user_registration SET buttons = '". $btn_json ."', buttons_name = '". $btn_name_json ."' WHERE token_id = '$tokenId' ";

        $query_result = $conn->query($sql);
        if($query_result){
            $response['status'] = true;
            $response['msg']    = "You information updated successfully";

        } else {
            $response['status'] = false;
            $response['msg']    = "Something went wrong. Please try agian later!!";
        }
        
        echo json_encode($response);
    }

    if($callBack == "getButton") {


        $sql12 = "SELECT * FROM `session` WHERE id=1";
        $query_result12 = $conn->query($sql12);
        $records12    = $query_result12->fetch_assoc();
        $tokenId = $records12['token_id'];


        $sql = "SELECT *  FROM `user_registration` WHERE token_id = '$tokenId' ";

        $query_result = $conn->query($sql);
        

        $sql_result = $query_result->num_rows;

        $all_records = $query_result->fetch_assoc();

        if($sql_result >0) { 
            $response['buttons'] = $all_records['buttons'];
            $response['buttons_name'] = $all_records['buttons_name'];
            $response['status']    = true;
        } else {
            $response['result'] = '';
            $response['status']    = false;
        }

        
        
        echo json_encode($response);
    }

    if($callBack == "get_on_off_status") {


        $sql12 = "SELECT * FROM `session` WHERE id=1";
        $query_result12 = $conn->query($sql12);
        $records12    = $query_result12->fetch_assoc();
        $tokenId = $records12['token_id'];

        $sql = "SELECT `button_on_off` FROM `user_registration` WHERE token_id = '$tokenId' ";

        $query_result = $conn->query($sql);
        

        $sql_result = $query_result->num_rows;

        if($sql_result >0) { 
            $response['result'] = $query_result->fetch_assoc();
            $response['status']    = true;
        } else {
            $response['result'] = '';
            $response['status']    = false;
        }

        
        
        echo json_encode($response);
    }

    if($callBack == "button_on_off") {
        $name   = $request->form_data;


        $sql12 = "SELECT * FROM `session` WHERE id=1";
        $query_result12 = $conn->query($sql12);
        $records12    = $query_result12->fetch_assoc();
        $tokenId = $records12['token_id'];

        $sql1 = "SELECT `button_on_off` FROM `user_registration` WHERE token_id = '$tokenId' ";
        $query1 = $conn->query($sql1);
        $query_result1 = $query1->fetch_assoc();            

        $button_on_off_arr = json_decode($query_result1['button_on_off']);
        //print_r($button_on_off_arr->d0);
        $btn_val = $button_on_off_arr->$name;

        if ($btn_val == 'OFF') {
            $val = 'ON';
        } else {
            $val = 'OFF';
        }
    
        

        $button_on_off_arr->$name = $val;


        $btn_json = json_encode($button_on_off_arr);

        
        $sql12 = "SELECT * FROM `session` WHERE id=1";
        $query_result12 = $conn->query($sql12);
        $records12    = $query_result12->fetch_assoc();
        $tokenId = $records12['token_id'];
        
        $sql = "UPDATE user_registration SET button_on_off = '". $btn_json ."' WHERE token_id = '$tokenId' ";
        $query_result = $conn->query($sql);
        if($query_result){
            $response['status'] = true;
            $response['msg']    = "Success!";

        } else {
            $response['status'] = false;
            $response['msg']    = "Something went wrong. Please try agian later!!";
        }
        
        echo json_encode($response);
    }

}

?>
